/*******************************************************
I/O Ports initialization created by the
CodeWizardAVR V3.31 UL Automatic Program Generator
� Copyright 1998-2017 Pavel Haiduc, HP InfoTech s.r.l.
http://www.hpinfotech.com

Project : CIV Router
*******************************************************/

#ifndef _PORTS_INIT_INCLUDED_
#define _PORTS_INIT_INCLUDED_

// Ports initialization
void ports_init(void);
// Virtual Ports initialization
void vports_init(void);

#endif
